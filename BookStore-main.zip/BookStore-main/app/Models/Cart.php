<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Cart extends Model
{
    use HasFactory;

    protected $fillable = ['user_id'];

    // Một giỏ hàng sẽ có nhiều sản phẩm chi tiết
    public function items()
    {
        return $this->hasMany(CartItem::class);
    }
}
